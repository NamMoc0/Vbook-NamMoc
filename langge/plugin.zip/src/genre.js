// genre.js - The loai cua Fanqie (Ca Chua) - Day du the loai Nam Tan
// Input: "genre" tu home.js
load("config.js");

function execute(input) {
    // Danh sach day du the loai Nam Tan (gender=1) tren Fanqie
    // type ID lay tu API chinh thuc cua Fanqie
    var genres = [
        // ===== NAM TAN =====
        { title: "🌀 [Nam] Huyền Huyễn Truyền Thống",   type: "7",   gender: "1" },
        { title: "⚔️ [Nam] Tiên Hiệp Đông Phương",       type: "517", gender: "1" },
        { title: "🏙️ [Nam] Đô Thị / Dị Năng",           type: "1",   gender: "1" },
        { title: "🚀 [Nam] Khoa Huyễn / Tận Thế",        type: "8",   gender: "1" },
        { title: "📜 [Nam] Lịch Sử / Quân Sự",           type: "12",  gender: "1" },
        { title: "👻 [Nam] Huyền Nghi / Linh Dị",        type: "10",  gender: "1" },
        { title: "🏰 [Nam] Kỳ Huyễn Tây Phương",         type: "259", gender: "1" },
        { title: "🎮 [Nam] Game / Thể Thao",              type: "746", gender: "1" },
        { title: "⚙️ [Nam] Hệ Thống / Kim Chỉ",          type: "19",  gender: "1" },
        { title: "⏰ [Nam] Xuyên Không",                  type: "37",  gender: "1" },
        { title: "🔄 [Nam] Trọng Sinh",                   type: "36",  gender: "1" },
        { title: "🌾 [Nam] Điền Văn / Nhẹ Nhàng",        type: "23",  gender: "1" },
        { title: "😄 [Nam] Huyền Huyễn Hài / Não Động",  type: "6",   gender: "1" },
        { title: "🔮 [Nam] Dị Thế Linh Dị",              type: "11",  gender: "1" },
        { title: "👹 [Nam] Tu Tiên / Đạo Pháp",          type: "5",   gender: "1" },
        { title: "🐉 [Nam] Vũ Hiệp / Cổ Phong",          type: "4",   gender: "1" },
        { title: "👑 [Nam] Đế Vương / Quyền Mưu",        type: "2",   gender: "1" },
        { title: "🌏 [Nam] Đô Thị Tu Chân",              type: "3",   gender: "1" },
        { title: "🎯 [Nam] Cạnh Tranh Thương Trường",    type: "9",   gender: "1" },
        { title: "📱 [Nam] Xuyên Nhanh",                  type: "17",  gender: "1" },
        { title: "🦁 [Nam] Luyện Thú / Thú Thánh",      type: "21",  gender: "1" },
        { title: "🔬 [Nam] Siêu Năng / Dị Năng",         type: "22",  gender: "1" },
        { title: "⛵ [Nam] Hàng Hải / Phiêu Lưu",       type: "25",  gender: "1" },
        { title: "🏆 [Nam] Thể Thao Cạnh Tranh",         type: "26",  gender: "1" }
    ];

    var result = [];
    for (var i = 0; i < genres.length; i++) {
        var g = genres[i];
        var url = BASE_URL + "/get_discover?source=番茄&tab=小说&type=" + g.type + "&gender=" + g.gender + "&genre_type=0";
        result.push({ title: g.title, input: url, script: "gen.js" });
    }

    return Response.success(result);
}
