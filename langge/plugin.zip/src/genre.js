// genre.js - The loai cua Fanqie (Ca Chua)
// Input: "genre" tu home.js
load("config.js");

function execute(input) {
    var genres = [
        { title: "📚 [Nam] Huyền Huyễn",         type: "7",   gender: "1" },
        { title: "📚 [Nam] Tu Tiên",              type: "517", gender: "1" },
        { title: "📚 [Nam] Đô Thị",              type: "1",   gender: "1" },
        { title: "📚 [Nam] Khoa Huyễn Tận Thế",  type: "8",   gender: "1" },
        { title: "📚 [Nam] Lịch Sử",             type: "12",  gender: "1" },
        { title: "📚 [Nam] Huyền Nghi",          type: "10",  gender: "1" },
        { title: "📚 [Nam] Kỳ Huyễn Tiên Hiệp",  type: "259", gender: "1" },
        { title: "📚 [Nam] Game & Thể Thao",     type: "746", gender: "1" },
        { title: "📚 [Nam] Hệ Thống",            type: "19",  gender: "1" },
        { title: "📚 [Nam] Xuyên Không",         type: "37",  gender: "1" },
        { title: "📚 [Nam] Trọng Sinh",          type: "36",  gender: "1" },
        { title: "📚 [Nam] Điền Văn",            type: "23",  gender: "1" },
        { title: "💕 [Nữ] Huyền Huyễn",         type: "7",   gender: "2" },
        { title: "💕 [Nữ] Ngôn Tình Đô Thị",    type: "1",   gender: "2" },
        { title: "💕 [Nữ] Cổ Đại Ngôn Tình",    type: "12",  gender: "2" },
        { title: "💕 [Nữ] Tu Tiên",             type: "517", gender: "2" },
        { title: "💕 [Nữ] Xuyên Không",         type: "37",  gender: "2" },
        { title: "💕 [Nữ] Trọng Sinh",          type: "36",  gender: "2" }
    ];

    var result = [];
    for (var i = 0; i < genres.length; i++) {
        var g = genres[i];
        var url = BASE_URL + "/get_discover?source=番茄&tab=小说&type=" + g.type + "&gender=" + g.gender + "&genre_type=0";
        result.push({ title: g.title, input: url, script: "gen.js" });
    }

    return Response.success(result);
}
