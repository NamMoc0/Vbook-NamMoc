// home.js - Trang chu Fanqie (Ca Chua)
// Chi hien thi cac bang xep hang cua Fanqie
load("config.js");

function execute() {
    return Response.success([
        { title: "🍅 Fanqie - Thể Loại", input: "genre", script: "genre.js" },
        { title: "🏆 Bảng Đỉnh Phong",  input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=巅峰榜&gender=1&is_ranking=1", script: "gen.js" },
        { title: "🔥 Bảng Nhiệt Tìm",   input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=热搜榜&gender=1&is_ranking=1", script: "gen.js" },
        { title: "⭐ Bảng Đề Xuất",     input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=推荐榜&gender=1&is_ranking=1", script: "gen.js" },
        { title: "✍️ Bảng Cập Nhật",    input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=爆更榜&gender=1&is_ranking=1", script: "gen.js" }
    ]);
}
